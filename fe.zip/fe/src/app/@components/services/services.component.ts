import { Subject } from 'rxjs';
import { HomeYubikeyInputComponent } from './../home/home-yubikey-input/home-yubikey-input.component';
import { OtpValidaterComponent } from './../home/otp-validater/otp-validater.component';
import { mailService } from './../../@core/services/mail.service';
import { Component, OnInit } from '@angular/core';
import {UserService} from "../../@core/services/user.service";
import {NbDialogService} from "@nebular/theme";
import {PingIdService} from "../../@core/services/pingid.service";
import {HttpClient} from "@angular/common/http";
import {HomeDialogComponent} from "../home/home-dialog/home-dialog.component";
import {HomeQrCodeComponent} from "../home/home-qr-code/home-qr-code.component";
import {HomeQrCodeGoogleComponent} from "../home/home-qr-code-google/home-qr-code-google.component";
import {JwtAuthService} from "../../@core/services/jwt-auth.service";
import {NbMenuService} from '@nebular/theme';
import { AppConst } from './../../@core/utils/app-const';
import { environment } from './../../../environments/environment';
import { HomeSmsInputComponent } from '../home/home-sms-input/home-sms-input.component';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss']
})
export class ServicesComponent implements OnInit {
  user;
  activationCode;
  deviceList = [];
  primaryDevice;
  mfaTriggered = false;
  mfaApproved = false;
  mfaRejected = false;
  userFound = false;
  userName;
  userNotFound = false;
  errMsg;
  AdminStatus;
  mfaErrMsg;
  pairingKeyUri;
  pairingKey;
  sessionId;
  userActivat = false;
  userSuspend = false;
  userBypassed = false;
  userActivatError = false;
  userSuspendError = false;
  userBypassedError = false;
  //items = [{ title: 'ByPass MFA' }, { title: 'Enable User' }, { title: 'Disable User' }];
  softToken: string = "false";
  hardToken: string = "false";
  desktopToken: string = "false";
  otpToken: string = "false";
  smsToken: string = "false";
  sessionUser;
  userTokenType;

  constructor(
    private userService: UserService,
    private jwtAuth: JwtAuthService,
    private dialogService: NbDialogService,
    private pingidService: PingIdService,
    private http: HttpClient,
    private menuService: NbMenuService,
    private mailService: mailService
  ) {
    this.sessionUser = jwtAuth.getUser();
  }

  unpairDevice(device) {
    this.dialogService.open(HomeDialogComponent, {
      context: {
        title: 'Unpair Device',
        message: 'Are you sure you want to unpair this device?'
      },
      hasBackdrop: true,
    }).onClose.subscribe(res => {
      if (res) {
        this.pingidService.unpairDevice(device.deviceId, this.user.userName).subscribe(
          res => {
            this.mailService.adminServiceMail(this.user.userName,AppConst.MAIL_TASK_helpDeskUnPair,this.sessionUser.sub);
            this.searchUser();
          }, error => {
            console.log(error);
          }
        )
      }
    });
  }

  getActivationCode(type) {
    this.pingidService.getActivationCode(type, this.user.userName).subscribe(
      res => {
        const result: any = res;
        this.activationCode = result.activationCode;
        if(this.activationCode) {
        this.dialogService.open(HomeQrCodeComponent, {
          context: {
            type: type,
            title: 'Register ' + type + ' Device',
            message: 'Please scan the QR code with your PingID ' + type + ' app or input paring code manually.',
            code: this.activationCode,
            qrcode: 'https://idpxnyl3m.pingidentity.com/pingid/QRRedirection?' + btoa(this.activationCode),
            userName: this.user.userName,
            mailTask: AppConst.MAIL_TASK_helpDeskPair,
            adminUser: this.sessionUser.sub,
          },
          hasBackdrop: true,
          closeOnBackdropClick: false
        }).onClose.subscribe(res => {
          if (res) {
            this.searchUser();
          }
        });
      } else {
        this.dialogService.open(HomeDialogComponent, {
          context: {
            title: 'Max Number of Device',
            message: 'You have reach MAX number of device'
          },
          hasBackdrop: true,
        }).onClose.subscribe(res => {
          if (res) {
              }
            }
            )
      }
      }, error => {
        console.log(error);
      }
    )
  }

  makeDevicePrimary (device) {
    this.dialogService.open(HomeDialogComponent, {
      context: {
        title: 'Change Primary MFA Device',
        message: 'Are you sure you want to make this one your primary MFA device?'
      },
      hasBackdrop: true,
    }).onClose.subscribe(res => {
      if (res) {
        this.pingidService.makeDevicePrimary(device.deviceId, this.user.userName).subscribe(
          res => {
            this.searchUser();
          }, error => {
            console.log(error);
          }
        )
      }
    });


  }

  yubikeyStartPairing() {
    this.dialogService.open(HomeYubikeyInputComponent, {
      context: {
        title: 'Register ' + ' Authenticator',
        message: 'Please input paring code manually.',
        userName: this.user.userName,
        adminUser: this.sessionUser.sub,
        mailTask: AppConst.MAIL_TASK_helpDeskPair,
      },
      hasBackdrop: true,
      closeOnBackdropClick: false
    }).onClose.subscribe(res => {
      if (res) {
        this.searchUser();
      }
    });
  }



  AuthenticatorAppStartPairing() {
    this.pingidService.AuthenticatorAppStartPairing(this.user.userName).subscribe(
      res => {
        const result: any = res;
        this.pairingKeyUri = result.pairingKeyUri;
        this.pairingKey = result.pairingKey;
        this.sessionId = result.sessionId;
        if (this.pairingKey) {
        this.dialogService.open(HomeQrCodeGoogleComponent, {
          context: {
            title: 'Register ' + ' Authenticator',
            message: 'Please scan the QR code with your Authenticator ' + ' app or input paring code manually.',
            qrcode: this.pairingKeyUri,
            code: this.pairingKey,
            sessionId: this.sessionId,
            user: this.user,
            userName: this.user.userName,
            adminUser: this.sessionUser.sub,
            mailTask: AppConst.MAIL_TASK_helpDeskPair,
          },
          hasBackdrop: true,
          closeOnBackdropClick: false
        }).onClose.subscribe(res => {
          if (res) {
          }
        });
      } else {
        this.dialogService.open(HomeDialogComponent, {
          context: {
            title: 'Max Number of Device',
            message: 'You have reach MAX number of device'
          },
          hasBackdrop: true,
        }).onClose.subscribe(res => {
          if (res) {
              }
            }
            )
      }
      }, error => {
        console.log(error);
      }
    )
  }

  smsStartPairing() {
    this.dialogService.open(HomeSmsInputComponent, {
      context: {
        title: 'Register ' + ' SMS',
        message: 'Please input phone number' + '',
        user: this.user,
        sessionId: this.sessionId,
        userName: this.user.userName,
        adminUser: this.sessionUser.sub,
        mailTask: AppConst.MAIL_TASK_helpDeskPair,
      },
      hasBackdrop: true,
      closeOnBackdropClick: false
    }).onClose.subscribe(res => {
      if (res) {
        this.searchUser();
      }
    });
  }


  testMFA(testDevice) {
    this.mfaTriggered = true;
    this.pingidService.testMFA(testDevice.deviceId, this.user.userName).subscribe(
      res => {
        const result: any = res;
        if (result.errorMsg) {
          this.mfaRejected = true;
          this.mfaErrMsg = result.errorMsg;
          this.mfaTriggered = false;
        } else {
          this.mfaApproved = true;
          this.mfaTriggered = false;
        }

        setTimeout(() =>
          {
            this.clearAlerts();
          },
          5000);
      }, error => {
        console.log(error);
      }
    )
  }



  testMFADesktop(testDevice){
    //need modify starOfflineAuth method
    this.pingidService.startOfflineAuth(testDevice.deviceId, this.user.userName).subscribe(
      res => {
        const result: any = res;
        if (result.sessionId) {
          this.dialogService.open(OtpValidaterComponent, {
            context: {
              title: 'OTP Verification',
              message: 'Please input OTP generated from your device',
              sessionId: result.sessionId,
              userName: this.user.userName,
              spAlias: "web",
            },
            hasBackdrop: true,
          }).onClose.subscribe(res => {
            if (res) {
              this.searchUser();
              }
            }, error => {
              console.log(error);
             }
            )
        } else {
          this.mfaRejected = true;
          this.mfaErrMsg = result.errorMsg;
          this.mfaTriggered = false;
        }

        setTimeout(() =>
          {
            this.clearAlerts();
          },
          5000);
      }, error => {
        console.log(error);
      }
    )

  }

  testMFASMS(testDevice){
    this.pingidService.backupAuthentication(this.sessionUser.sub, testDevice.phoneNumber, "SMS").subscribe(
      res => {
        const result: any = res;
        if (result.sessionId) {
          this.dialogService.open(OtpValidaterComponent, {
            context: {
              title: 'OTP Verification',
              message: 'Please input OTP received from your phone',
              sessionId: result.sessionId,
              userName: this.user.userName,
              spAlias: "rescuecode",
            },
            hasBackdrop: true,
          }).onClose.subscribe(res => {
            if (res) {
              this.searchUser();
              }
            }, error => {
              console.log(error);
             }
            )
        } else {
          this.mfaRejected = true;
          this.mfaErrMsg = result.errorMsg;
          this.mfaTriggered = false;
        }

        setTimeout(() =>
          {
            this.clearAlerts();
          },
          5000);
      }, error => {
        console.log(error);
      }
    )
  }


/*  testMFA() {
    for (let i = 0; i < this.deviceList.length; i++) {
      if (this.deviceList[i].deviceRole.toLowerCase() === 'primary') {
        this.primaryDevice = this.deviceList[i];
      }
    }

    this.mfaTriggered = true;
    this.pingidService.testMFA(this.primaryDevice.deviceId, this.sessionUser.sub).subscribe(
      res => {
        const result: any = res;
        if (result.errorMsg) {
          this.mfaRejected = true;
          this.mfaErrMsg = result.errorMsg;
          this.mfaTriggered = false;
        } else {
          this.mfaApproved = true;
          this.mfaTriggered = false;
        }

        setTimeout(() =>
          {
            this.clearAlerts();
          },
          5000);
      }, error => {
        console.log(error);
      }
    )
  }
*/

  clearAlerts() {
    this.mfaRejected = false;
    this.mfaApproved = false;
    this.mfaTriggered = false;
    this.userNotFound = false;
    this.userBypassed = false;
    this.userActivat = false;
    this.userSuspend = false;
    this.userBypassedError = false;
    this.userActivatError = false;
    this.userSuspendError = false;
  }

  searchUser() {
    this.http.get(`${environment.apiURL}/profile?user=${this.userName}`).subscribe(res => {
      this.userTokenType = res;
        this.hardToken = this.userTokenType.hardToken.toString();
        this.softToken = this.userTokenType.softToken.toString();
        this.desktopToken = this.userTokenType.desktopToken.toString();
        this.otpToken = this.userTokenType.otpToken.toString();
        this.smsToken = this.userTokenType.SMSToken.toString();
      this.userService.getUserDetailsByUsername(this.userName).subscribe(
        res => {
          this.user = res;
          this.deviceList = this.user.devicesDetails;
          this.userFound = true;
        }, error => {
          this.userNotFound = true;
          this.userFound = false;
          console.log(error);
          this.errMsg = error.error;
          setTimeout(() =>
            {
              this.clearAlerts();
            },
            5000);
        }
      )
      }, error => {
        this.userService.getUserDetailsByUsername(this.userName).subscribe(
          res => {
            this.user = res;
            this.deviceList = this.user.devicesDetails;
            this.userFound = true;
          }, error => {
            this.userNotFound = true;
            this.userFound = false;
            console.log(error);
            this.errMsg = error.error;
            setTimeout(() =>
              {
                this.clearAlerts();
              },
              5000);
          }
        )
      }
    )
    //this.softToken = this.user.softToken;
    //this.hardToken = this.user.hardToken;
    //this.desktopToken = this.user.desktopToken;
  }

  searchUserProfile(){
    this.http.get(`${environment.apiURL}/profile?user=${this.userName}`).subscribe(res => {
      this.userTokenType = res;
      this.hardToken = this.userTokenType.hardToken.toString();
      this.softToken = this.userTokenType.softToken.toString();
      this.desktopToken = this.userTokenType.desktopToken.toString();
      this.otpToken = this.userTokenType.otpToken.toString();
      }, error => {
      }
    )
  }

  ActivateUser() {
    this.dialogService.open(HomeDialogComponent, {
      context: {
        title: 'Enable User',
        message: 'Are you sure you want to enable this user?'
      },
      hasBackdrop: true,
    }).onClose.subscribe(res => {
      if (res) {
      this.pingidService.ActivateUser(this.userName).subscribe(
      res => {
        const result: any = res;
        if (result.errorId == "200") {
          this.userActivat = true;
          this.mailService.adminServiceMail(this.user.userName,AppConst.MAIL_TASK_enable,this.sessionUser.sub);
          this.searchUser();
        } else {
          this.userActivatError = true;
          this.mfaErrMsg = "Error occured during user Activate";
        }
        setTimeout(() =>
        {
          this.clearAlerts();
        },
        5000);
      }, error => {
        console.log(error);
        }
       )
      }
     }
    )
   }

  SuspendUser() {
    this.dialogService.open(HomeDialogComponent, {
      context: {
        title: 'Disable User',
        message: 'Are you sure you want to disable this user?'
      },
      hasBackdrop: true,
    }).onClose.subscribe(res => {
      if (res) {
    this.pingidService.SuspendUser(this.userName).subscribe(
      res => {
        const result: any = res;
        if (result.errorId == "200") {
          this.userSuspend = true;
          this.mailService.adminServiceMail(this.user.userName,AppConst.MAIL_TASK_disable,this.sessionUser.sub);
          this.searchUser();
        } else {
          this.userSuspendError = true;
          this.mfaErrMsg = "Error occured during user Disable";
        }
        setTimeout(() =>
        {
          this.clearAlerts();
        },
        5000);
      }, error => {
        console.log(error);
       }
      )
     }
    }
   )
  }


  ToggleUserBypass() {
    this.dialogService.open(HomeDialogComponent, {
      context: {
        title: 'Bypass User MFA',
        message: 'Are you sure you want to bypass MFA for this user?'
      },
      hasBackdrop: true,
    }).onClose.subscribe(res => {
      if (res) {
    this.pingidService.ToggleUserBypass(this.userName).subscribe(
      res => {
        const result: any = res;
        if (result.errorId == "200") {
          this.userBypassed = true;
          this.mailService.adminServiceMail(this.user.userName,AppConst.MAIL_TASK_bypass,this.sessionUser.sub);
          this.searchUser();
        } else {
          this.userBypassedError = true;
          this.mfaErrMsg = "Error occured during user Bypass";
        }
        setTimeout(() =>
        {
          this.clearAlerts();
        },
        5000);
      }, error => {
        console.log(error);
       }
      )
     }
    }
   )
  }


  ngOnInit(): void {
    this.AdminStatus = this.jwtAuth.getAdmin();
  }
}
