export class User {
  id: any;
  username: string;
  password: string;
  fname?: string;
  lname?: string;
  email?: string;
  roles?: string[];
}
