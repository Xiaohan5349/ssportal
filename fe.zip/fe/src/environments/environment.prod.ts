import {config} from "../config";

export const environment = {
  production: false,
  apiURL: config.apiUrl
};
